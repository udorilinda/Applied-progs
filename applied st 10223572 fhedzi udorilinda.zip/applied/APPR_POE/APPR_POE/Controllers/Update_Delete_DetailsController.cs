﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace APPR_POE.Controllers
{
    public class Update_Delete_DetailsController : Controller
    {
        string conn = "Server=localhost\\MSSQLSERVER06;Database=master;Trusted_Connection=Trues";
        // GET: Update_Delete_Details
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult MonentaryDelete(int id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conn))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM MonetaryDonations WHERE Id = @Id", con);
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully!!!!!!");
                    return RedirectToAction("Index");
                }
            }

            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}